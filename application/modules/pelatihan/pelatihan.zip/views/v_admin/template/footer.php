<footer class="main">

&copy;
<?php echo date('Y') ?>
<strong> SIPI</strong> (Sistem Informasi Pendaftaran Pelatihan Industri)


	
</div>

	<!-- Data table -->
	<link rel="stylesheet" href="<?php echo base_url() ?>assets/back-end/js/datatables/datatables.css">
	<!-- Imported styles on this page -->
	<link rel="stylesheet" href="<?php echo base_url() ?>assets/back-end/js/select2/select2-bootstrap.css">
	<link rel="stylesheet" href="<?php echo base_url() ?>assets/back-end/js/select2/select2.css">
	<link rel="stylesheet" href="<?php echo base_url() ?>assets/back-end/js/selectboxit/jquery.selectBoxIt.css">
	<link rel="stylesheet" href="<?php echo base_url() ?>assets/back-end/js/daterangepicker/daterangepicker-bs3.css">
	<link rel="stylesheet" href="<?php echo base_url() ?>assets/back-end/js/icheck/skins/minimal/_all.css">
	<link rel="stylesheet" href="<?php echo base_url() ?>assets/back-end/js/icheck/skins/square/_all.css">
	<link rel="stylesheet" href="<?php echo base_url() ?>assets/back-end/js/icheck/skins/flat/_all.css">
	<link rel="stylesheet" href="<?php echo base_url() ?>assets/back-end/js/icheck/skins/futurico/futurico.css">
	<link rel="stylesheet" href="<?php echo base_url() ?>assets/back-end/js/icheck/skins/polaris/polaris.css">
	<link rel="stylesheet" href="<?php echo base_url() ?>assets/back-end/js/wysihtml5/bootstrap-wysihtml5.css">
	<link rel="stylesheet" href="<?php echo base_url() ?>assets/back-end/js/codemirror/lib/codemirror.css">
	<link rel="stylesheet" href="<?php echo base_url() ?>assets/back-end/js/uikit/addons/css/markdownarea.css">
	<!-- Bottom scripts (common) -->
	<script src="<?php echo base_url() ?>assets/back-end/js/gsap/TweenMax.min.js"></script>
	<script src="<?php echo base_url() ?>assets/back-end/js/jquery-ui/js/jquery-ui-1.10.3.minimal.min.js"></script>
	<script src="<?php echo base_url() ?>assets/back-end/js/bootstrap.js"></script>
	<script src="<?php echo base_url() ?>assets/back-end/js/joinable.js"></script>
	<script src="<?php echo base_url() ?>assets/back-end/js/resizeable.js"></script>
	<script src="<?php echo base_url() ?>assets/back-end/js/neon-api.js"></script>
	<script src="<?php echo base_url() ?>assets/back-end/js/wysihtml5/wysihtml5-0.4.0pre.min.js"></script>
	<!-- JavaScripts initializations and stuff -->
	<!-- Imported scripts on this page -->
	<script src="<?php echo base_url() ?>assets/back-end/js/datatables/datatables.js"></script>
	<script src="<?php echo base_url() ?>assets/back-end/js/select2/select2.min.js"></script>
	<!-- <script src="<?php echo base_url() ?>assets/back-end/js/bootstrap-tagsinput.min.js"></script> -->
	<script src="<?php echo base_url() ?>assets/back-end/js/typeahead.min.js"></script>
	<!-- <script src="<?php echo base_url() ?>assets/back-end/js/selectboxit/jquery.selectBoxIt.min.js"></script> -->
	<script src="<?php echo base_url() ?>assets/back-end/js/bootstrap-datepicker.js"></script>
	<script src="<?php echo base_url() ?>assets/back-end/js/bootstrap-timepicker.min.js"></script>
	<script src="<?php echo base_url() ?>assets/back-end/js/bootstrap-colorpicker.min.js"></script>
	<script src="<?php echo base_url() ?>assets/back-end/js/moment.min.js"></script>
	<script src="<?php echo base_url() ?>assets/back-end/js/daterangepicker/daterangepicker.js"></script>
	<script src="<?php echo base_url() ?>assets/back-end/js/jquery.multi-select.js"></script>
	<script src="<?php echo base_url() ?>assets/back-end/js/icheck/icheck.min.js"></script>
	<script src="<?php echo base_url() ?>assets/back-end/js/neon-chat.js"></script>
	<script src="<?php echo base_url() ?>assets/back-end/js/jquery.validate.min.js"></script>
	<script src="<?php echo base_url() ?>assets/back-end/js/fileinput.js"></script>
	<script src="<?php echo base_url() ?>assets/back-end/js/dropzone/dropzone.js"></script>
	<script src="<?php echo base_url() ?>assets/back-end/js/confirm/jquery-confirm.min.js"></script>
	<!-- JavaScripts initializations and stuff -->
	<!-- Demo Settings -->
	<script src="<?php echo base_url() ?>assets/back-end/js/neon-demo.js"></script>
	<script src="<?php echo base_url() ?>assets/back-end/js/neon-custom.js"></script>
	<script src="<?php echo base_url() ?>assets/back-end/js/wysihtml5/bootstrap-wysihtml5.js"></script>
	<script src="<?php echo base_url() ?>assets/back-end/js/ckeditor/ckeditor.js"></script>
	<script src="<?php echo base_url() ?>assets/back-end/js/ckeditor/adapters/jquery.js"></script>
	<script src="<?php echo base_url() ?>assets/back-end/js/jquery.inputmask.bundle.js"></script>

	