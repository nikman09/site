<div class="container">
	<div class="row">
		<div class="col-md-12">
			<hr class="no-top-margin" />
		</div>
	</div>	
</div>

<div class="container">

	<div class="row vspace" style="padding:10px">
	<?php pesan_get2('msg',"Berhasil Melakukan Pendaftaran Pelatihan !","") ?>
		<div class="col-md-12">
		
		<h3 align="center">Status Pendaftaran Pelatihan</h3>
		
		 	<P align="center"> Sudah Pernah Melakukan Pendafataran Pelatihan Ini, Silahkan Pilih Pendaftaran Pelatihan Yang Lain <a href="<?php echo base_url() ?>/pelatihan/informasi">di sini !</a> </p>
			<p align="right">
			&nbsp
			</p>
	</div>
</div>
</div>

