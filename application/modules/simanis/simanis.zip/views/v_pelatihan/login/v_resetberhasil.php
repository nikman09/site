<div class="container">
	<div class="row">
		<div class="col-md-12">
			<hr class="no-top-margin" />
		</div>
	</div>	
</div>

<div class="container">
	<div class="row vspace">
		<div class="col-md-12">
	
                    <div class="row">
					
					<div class="col-md-6">
					<h3>Reset Password Berhasil</h3>
					<hr/>
					<p> <a href="<?php echo base_url(); ?>simanis/login" class="btn btn-primary btn-icon icon-left" style=""><i class="fa fa-sign-in"></i> Login </a> </p>
					<br/>
						
						</div>
						<div class="col-md-6">
						<p align="center">
							<img src="<?php echo base_url() ?>assets/images/lupa.png" class="img-responsive"  width="400px" margin="0 auto" />
						</p>
						</div>
                    </div>
		</div>
	</div>
</div>

