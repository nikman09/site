<div class="container">
	<div class="row">
		<div class="col-md-12">
			<hr class="no-top-margin" />
		</div>
	</div>	
</div>

<div class="container">

	<div class="row vspace" style="padding:10px">
	<h3>FAQ</h3>
		<br />
		
		
		<div class="row">
		
			<div class="col-md-12">
		
				<div class="panel-group joined" id="accordion-test-2">
				
					<div class="panel panel-default">
						<div class="panel-heading">
							<h4 class="panel-title">
								<a data-toggle="collapse" data-parent="#accordion-test-2" href="#collapseOne-2">
									Bagaimmana Cara Mendaftar ?
								</a>
							</h4>
						</div>
						<div id="collapseOne-2" class="panel-collapse collapse">
							<div class="panel-body">
							Pendaftaran dilakukan secara online melalui Link <a href="disperin.kalselprov.go.id" target="_blank">disperin.kalselprov.go.id/pelatihan</a>.
							</div>
						</div>
					</div>
					
					<div class="panel panel-default">
						<div class="panel-heading">
							<h4 class="panel-title">
								<a data-toggle="collapse" data-parent="#accordion-test-2" href="#collapseTwo-2" class="collapsed">
									Bagaimana Melihat Informasi Pelatihan ?
								</a>
							</h4>
						</div>
						<div id="collapseTwo-2" class="panel-collapse collapse">
							<div class="panel-body">
								Informasi Pelatihan Dapat dilihat  melalui link <a href="disperin.kalselprov.go.id" target="_blank">disperin.kalselprov.go.id/pelatihan/informasi</a>.
							</div>
						</div>
					</div>
					
					
				</div>
		
			</div>

		
		
		
</div>

