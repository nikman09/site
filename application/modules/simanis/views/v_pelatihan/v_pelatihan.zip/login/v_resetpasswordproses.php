<div class="container">
	<div class="row">
		<div class="col-md-12">
			<hr class="no-top-margin" />
		</div>
	</div>	
</div>

<div class="container">
	<div class="row vspace">
		<div class="col-md-12">
	
                    <div class="row">
					
					<div class="col-md-6">
					<h3>Reset Password</h3>
					<hr/>
					<p>Silahkan cek email masuk  untuk mendapatkan link  reset password</p>
					<br/>
					<a href="<?php echo base_url(); ?>simanis/akun" style="float:right"> Daftar Akun <span style="color:#21a9e1"></span></a>
							 <a href="<?php echo base_url(); ?>simanis/login" style="float:right"> Login |  </a> 
					
						</div>
						<div class="col-md-6">
						<p align="center">
							<img src="<?php echo base_url() ?>assets/images/login.png" class="img-responsive"  width="400px" margin="0 auto" />
						</p>
						</div>
                    </div>
		</div>
	</div>
</div>

